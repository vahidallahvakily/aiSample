package com.example.demo.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModelItem {
    private Integer id;
    private Integer modelId;
    private String name;
    private String title;
    private String modelItemType;
}
