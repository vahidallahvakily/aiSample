package com.example.demo.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModelItemEnumeration {
    private Integer modelItemId;
    private String enumText;
    private Integer enumValue;
}
