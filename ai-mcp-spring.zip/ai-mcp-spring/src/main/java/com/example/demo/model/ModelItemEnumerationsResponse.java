package com.example.demo.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModelItemEnumerationsResponse {
    private List<ModelItemEnumeration> modelItemEnumerations;
}
